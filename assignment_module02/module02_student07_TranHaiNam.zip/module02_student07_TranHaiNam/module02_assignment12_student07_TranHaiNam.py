foo = ('a'),
bar = 'a',
ham = ('a', )



if foo == bar == ham:
    print(" Gía trị bằng nhau")
else:
    print("Gía trị không bằng nhau")
# Khi in cả 3 biến đều trả về giá trị là ('a',) mặc dù khác về hình thức, bài học ở đây giúp việc đọc code không bị nhầm lẫn.


foo1 = 'Đà Nẵng'
bar1 = 'Đà Nẵng'
print(foo1)
print(bar1)

if foo1 == bar1:
    print("Gía trị cũng bằng nhau")
else:
    print("Gía trị không bằng nhau")




