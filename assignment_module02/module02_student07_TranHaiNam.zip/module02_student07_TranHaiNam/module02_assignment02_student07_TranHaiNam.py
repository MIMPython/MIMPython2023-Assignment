
def foo(x):
    return x**2

if __name__=='__main__':
    print(foo(3))
    print(foo(-9))

